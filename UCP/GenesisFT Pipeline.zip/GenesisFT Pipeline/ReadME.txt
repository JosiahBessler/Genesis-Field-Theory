GenesisFT UCP Mass-Modeling Pipeline
=====================================

This repository provides a complete, reproducible pipeline for fitting galaxy
rotation curves using multiple dark-matter profiles—both classical
(NFW, Burkert, Einasto, Pseudo-Isothermal) and the **Universal Cored Profile (UCP)**
derived from Genesis Field Theory (Bessler 2025).

The pipeline wraps the SPARC rotation curve database and compares all profiles
under identical fitting conditions using LMFit, producing:

 • Best-fit parameters for each profile
 • Reduced chi-square, AIC, BIC
 • RAR residual statistics
 • Curve-shape tests
 • Scatter diagnostics
 • Strong-lensing predictions (Einstein radius)
 • Publication-ready rotation-curve, scatter, and lensing plots

The goal is *transparent, reproducible* comparison of physical and empirical
profiles using standardized tests.

-------------------------------------------------------------------------------

1. System Requirements
----------------------

Python 3.9–3.12

Required packages:

    pip install numpy scipy pandas lmfit matplotlib

This package is OS-independent and has been tested on:

 • Windows 10/11  
 • Linux (Ubuntu / Debian)  
 • macOS  

-------------------------------------------------------------------------------

2. Folder Structure
-------------------

Place all files exactly as follows:

    GenesisFT Pipeline/
        fit_all_multiDM.py
        download_sparc.py
        Functions/
        DarkMatter/
        Output/           <-- auto-generated
        SPARC/            <-- created when downloading data
        Databases/        <-- automatically populated
        README.txt
        LICENSE           <-- inherited from main GenFT repository

The SPARC database **is not included**. It is automatically downloaded into
`SPARC/` using `download_sparc.py`.

-------------------------------------------------------------------------------

3. How to Download SPARC Data
-----------------------------

Before running the pipeline, execute:

    python download_sparc.py

This script:

 • Downloads the official SPARC rotation curve models  
 • Downloads the SPARC "MaximumDisk" Python bundle  
 • Copies Functions/ and Databases/ required for SPARC compatibility  
 • Removes temporary ZIP files  
 • Preserves correct attribution to the SPARC team  

Proper SPARC citation (required in all publications):

    Lelli, F., McGaugh, S. S., & Schombert, J. M. (2016),
    “SPARC: Mass Models for 175 Disk Galaxies,”
    AJ, 152, 157.
    doi:10.3847/0004-6256/152/6/157

This repository does **not** redistribute SPARC data.

-------------------------------------------------------------------------------

4. Running the Pipeline
-----------------------

Once SPARC files are downloaded:

    python fit_all_multiDM.py

The pipeline will:

 • Generate preliminary & fiducial SPARC tables  
 • Fit every galaxy in SPARC against all enabled profiles  
 • Use multithreading automatically for speed  
 • Produce a master results table at:

       Output/Tables/MultiDM_all.csv

 • Produce plots at:

       Output/Plots/MultiDM_Rotation/
       Output/Plots/MultiDM_Scatter/
       Output/Plots/MultiDM_Curve/
       Output/Plots/MultiDM_Lensing/

The script also prints a **global performance summary** including:

 • median BIC  
 • median reduced chi²  
 • curve-shape and scatter statistics  
 • UCP vs Stable Attractor comparative summary  

-------------------------------------------------------------------------------

5. Reproducibility Notes
------------------------

This pipeline was designed for scientific reproducibility:

 • All dark-matter models share a unified interface and identical fitting conditions.  
 • SPARC data are consumed directly from the official source.  
 • All random processes are deterministic.  
 • No hidden priors or empirical corrections are applied to UCP.  
 • Plots are automatically skipped if too small to be meaningful.  

To fully reproduce results:

 • Use the same SPARC revision (download_sparc.py retrieves latest public version)  
 • Do not modify Functions/SPARC files except where explicitly documented  
 • Run on Python ≥ 3.9 with the package versions above  

-------------------------------------------------------------------------------

6. License
----------

All code in this repository is covered by the **license located in the root
directory** of the Genesis Field Theory project:

    https://github.com/JosiahBessler/Genesis-Field-Theory/

SPARC data copyrights remain fully with their original authors  
(Lelli, McGaugh, Schombert). Users must cite SPARC in all derivative work.

-------------------------------------------------------------------------------

7. Citation
-----------

If you use the **Universal Cored Profile (UCP)**, the **GenesisFT framework**, or this
**comparison pipeline**, please cite:

	Bessler, J. (2025),
	"The Universal Cored Profile (UCP)"


and the SPARC database:

    Lelli, F., McGaugh, S. S., & Schombert, J. M. (2016),
    "SPARC: Mass Models for 175 Disk Galaxies,"
    AJ, 152, 157.
    doi:10.3847/0004-6256/152/6/157

A machine-readable CITATION.cff file can be generated upon request.

-------------------------------------------------------------------------------

8. Contact
----------

For questions, collaboration, or theoretical discussion:

    Genesis Field Theory (GFT)
    GenesisFieldTheory@outlook.com
    GitHub: https://github.com/JosiahBessler/

-------------------------------------------------------------------------------

End of README
