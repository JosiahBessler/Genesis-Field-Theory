#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""NFW dark-matter halo profile.

Profile:
    rho(r) = rho_s / [ (r/rs) * (1 + r/rs)^2 ]

Parameters (lmfit.Parameters)
---------------------------------
``ps``
    Scale density rho_s in Msun / pc^3.
``rs``
    Scale radius r_s in kpc.
``G``
    Gravitational constant in kpc (km/s)^2 / Msun.

All radii are in kpc. Enclosed mass is returned in Msun, and Vrot in km/s.
"""

import numpy as np
import Functions.Convert as cn   # if it’s already there, keep it

# ------------------------------------------------------------------
# Lensing metadata + inner softening
# ------------------------------------------------------------------
# RHO_UNITS tells the pipeline what units rho(...) returns.
# - For profiles that are explicitly in Msun / pc^3, use "Msun_pc3"
# - For profiles that are in Msun / kpc^3, use "Msun_kpc3"
RHO_UNITS = "Msun_pc3"
RHO_EPS_KPC = 1.0e-3  # minimum radius used in lensing integrals [kpc]


def _safe_r_kpc(r):
    """Return radius in kpc with a small floor to avoid r -> 0 singularities."""
    r = np.asarray(r, dtype=float)
    return np.maximum(r, RHO_EPS_KPC)


def rho_raw(p, R_kpc):
    """
    NFW density profile.

    Returns rho in Msun / pc^3.
    """
    G  = p["G"].value
    rs = p["rs"].value    # [kpc]
    ps = p["ps"].value    # [Msun / pc^3]

    R_kpc_safe = _safe_r_kpc(R_kpc)
    x = R_kpc_safe / rs
    return ps / (x * (1.0 + x)**2)


def rho(p, R):
    return rho_raw(p, R)


def rho_safe(p, r_kpc):
    """Numerically safe wrapper around rho_raw for lensing."""
    r_min = 5e-2  # 0.05 kpc
    if r_kpc <= 0:
        r = r_min
    else:
        r = max(r_kpc, r_min)

    try:
        rho_val = float(rho_raw(p, r))
    except Exception:
        return 0.0

    if not np.isfinite(rho_val):
        return 0.0
    if rho_val < 0:
        rho_val = 0.0
    if rho_val > 1e20:
        rho_val = 1e20

    return rho_val


def M(p, r_kpc):
    """
    Enclosed mass M(<r) for NFW in Msun.

    Parameters
    ----------
    p : lmfit.Parameters
        ps : scale density [Msun/pc^3]
        rs : scale radius  [kpc]
    r_kpc : array_like
        Radius in kpc.

    Returns
    -------
    M_enc : ndarray
        Enclosed mass in Msun.
    """
    r = np.asarray(r_kpc, dtype=float)
    rho_s_pc3 = p["ps"].value
    r_s = p["rs"].value

    # Convert rho_s from Msun/pc^3 to Msun/kpc^3
    rho_s_kpc3 = rho_s_pc3 * 1.0e9  # (1 kpc)^3 = (1000 pc)^3 = 1e9 pc^3

    x = np.zeros_like(r, dtype=float)
    mask = r > 0
    x[mask] = r[mask] / r_s

    # Analytic enclosed mass:
    # M(r) = 4π ρ_s r_s^3 [ ln(1+x) - x/(1+x) ]
    prefac = 4.0 * np.pi * rho_s_kpc3 * r_s**3
    M_enc = np.zeros_like(r, dtype=float)
    M_enc[mask] = prefac * (np.log1p(x[mask]) - x[mask] / (1.0 + x[mask]))

    return M_enc


def g(p, r_kpc):
    """
    Radial acceleration g(r) in (km/s)^2 / kpc.

    Uses:
        g(r) = G * M(<r) / r^2
    """
    r = np.asarray(r_kpc, dtype=float)
    G = p["G"].value
    M_enc = M(p, r)

    g_val = np.zeros_like(r, dtype=float)
    R_safe = np.maximum(r, 1e-8)
    g_val = G * M_enc / (R_safe ** 2)
    return g_val


def Vrot(p, r_kpc):
    """
    Circular velocity V_c(r) in km/s.

    Uses:
        V_c^2(r) = G * M(<r) / r
    """
    r = np.asarray(r_kpc, dtype=float)
    G = p["G"].value
    R_safe = np.maximum(r, 1e-8)
    M_enc = M(p, R_safe)

    V = np.zeros_like(r, dtype=float)
    V[:] = np.sqrt(G * M_enc / R_safe)

    return V
