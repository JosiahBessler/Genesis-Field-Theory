#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""DC14 (Di Cintio+ 2014) double power-law dark-matter profile.

Profile:
    rho(r) = rho_s / ((r/r_s)^gamma * (1 + (r/r_s)^alpha)^{(beta - gamma)/alpha})

Parameters (lmfit.Parameters)
---------------------------------
``rho_s``
    Scale density [Msun / pc^3].
``r_s``
    Scale radius [kpc].
``alpha``, ``beta``, ``gamma``
    Shape parameters controlling inner/outer slopes.
``G``
    Gravitational constant in kpc km^2 / s^2 / Msun.
"""
import numpy as np
from scipy.integrate import cumulative_trapezoid
import Functions.Convert as cn   # if it’s already there, keep it

# ------------------------------------------------------------------
# Lensing metadata + inner softening
# ------------------------------------------------------------------
# RHO_UNITS tells the pipeline what units rho(...) returns.
# - For profiles that are explicitly in Msun / pc^3, use "Msun_pc3"
# - For profiles that are in Msun / kpc^3, use "Msun_kpc3"
RHO_UNITS = "Msun_pc3"
RHO_EPS_KPC = 1.0e-3  # minimum radius used in lensing integrals [kpc]


def _safe_r_kpc(r):
    """Return radius in kpc with a small floor to avoid r -> 0 singularities."""
    r = np.asarray(r, dtype=float)
    return np.maximum(r, RHO_EPS_KPC)


def rho_raw(p, R_kpc):
    R_kpc = _safe_r_kpc(R_kpc)
    rho_s = p["rho_s"].value
    r_s = p["r_s"].value
    alpha = p["alpha"].value
    beta = p["beta"].value
    gamma = p["gamma"].value

    x = R_kpc / r_s
    return (rho_s /
            (x ** gamma * (1.0 + x ** alpha) ** ((beta - gamma) / alpha)))


def rho(p, R):
    return rho_raw(p, R)


def rho_safe(p, r_kpc):
    """Numerically safe wrapper around rho_raw for lensing."""
    r_min = 5e-2  # 0.05 kpc
    if r_kpc <= 0:
        r = r_min
    else:
        r = max(r_kpc, r_min)

    try:
        rho_val = float(rho_raw(p, r))
    except Exception:
        return 0.0

    if not np.isfinite(rho_val):
        return 0.0
    if rho_val < 0:
        rho_val = 0.0
    if rho_val > 1e20:
        rho_val = 1e20

    return rho_val


def M(p, R):
    """Numerical enclosed mass for the DC14 profile."""
    R = np.asarray(R, dtype=float)
    R = np.atleast_1d(R)
    r_grid = np.logspace(-4, np.log10(max(np.max(R), 1e-3)), 400)
    rho_grid = rho(p, r_grid)
    integrand = rho_grid * 4.0 * np.pi * r_grid ** 2  # Msun/kpc^3 * kpc^2 = Msun/kpc
    M_grid = cumulative_trapezoid(integrand, r_grid, initial=0.0)
    return np.interp(R, r_grid, M_grid)


def g(p, R):
    R = np.asarray(R, dtype=float)
    R_safe = np.maximum(R, 1e-8)
    G = p["G"].value
    M_enc = M(p, R_safe)
    return G * M_enc / (R_safe * cn.kpc_to_km(R_safe))


def Vrot(p, R):
    R = np.asarray(R, dtype=float)
    return np.sqrt(g(p, R) * cn.kpc_to_km(R))

