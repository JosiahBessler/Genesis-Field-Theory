#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Pseudo-isothermal dark-matter halo profile.

Profile:
    rho(r) = rho0 / (1 + (r / rc)^2)

Parameters (lmfit.Parameters)
---------------------------------
``rho0``
    Central density [Msun / pc^3].
``rc``
    Core radius [kpc].
``G``
    Gravitational constant in kpc km^2 / s^2 / Msun (fixed by callers).
"""
import numpy as np
import Functions.Convert as cn   # if it’s already there, keep it

# ------------------------------------------------------------------
# Lensing metadata + inner softening
# ------------------------------------------------------------------
# RHO_UNITS tells the pipeline what units rho(...) returns.
# - For profiles that are explicitly in Msun / pc^3, use "Msun_pc3"
# - For profiles that are in Msun / kpc^3, use "Msun_kpc3"
RHO_UNITS = "Msun_pc3"
RHO_EPS_KPC = 1.0e-3  # minimum radius used in lensing integrals [kpc]


def _safe_r_kpc(r):
    """Return radius in kpc with a small floor to avoid r -> 0 singularities."""
    r = np.asarray(r, dtype=float)
    return np.maximum(r, RHO_EPS_KPC)


def rho_raw(p, R):
    R = _safe_r_kpc(R)
    rc = p["rc"].value
    rho0 = p["rho0"].value
    x = R / rc
    return rho0 / (1.0 + x**2)


def rho(p, R):
    return rho_raw(p, R)


def rho_safe(p, r_kpc):
    """Numerically safe wrapper around rho_raw for lensing."""
    r_min = 5e-2  # 0.05 kpc
    if r_kpc <= 0:
        r = r_min
    else:
        r = max(r_kpc, r_min)

    try:
        rho_val = float(rho_raw(p, r))
    except Exception:
        return 0.0

    if not np.isfinite(rho_val):
        return 0.0
    if rho_val < 0:
        rho_val = 0.0
    if rho_val > 1e20:
        rho_val = 1e20

    return rho_val


def M(p, R):
    """Analytic enclosed mass for the pseudo-isothermal sphere."""
    R = np.asarray(R, dtype=float)
    rc = p["rc"].value
    rho0 = p["rho0"].value

    x = R / rc
    prefac = 4.0 * np.pi * rho0 * cn.kpc_to_pc(rc) ** 3
    return prefac * (x - np.arctan(x))


def g(p, R):
    R = np.asarray(R, dtype=float)
    R_safe = np.maximum(R, 1e-8)
    G = p["G"].value
    M_enc = M(p, R_safe)
    return G * M_enc / (R_safe * cn.kpc_to_km(R_safe))


def Vrot(p, R):
    R = np.asarray(R, dtype=float)
    return np.sqrt(g(p, R) * cn.kpc_to_km(R))

