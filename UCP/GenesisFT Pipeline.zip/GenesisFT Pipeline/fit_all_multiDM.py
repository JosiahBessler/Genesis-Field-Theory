#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import sys
import numpy as np
import pandas as pd
import lmfit as lf
import warnings
from scipy.optimize import brentq
import threading

# Suppress noisy pandas "invalid value encountered in sqrt" RuntimeWarning
warnings.filterwarnings(
    "ignore",
    message="invalid value encountered in sqrt",
    module="pandas.core.arraylike"
)
# Suppress matplotlib "too many open figures" warnings
warnings.filterwarnings(
    "ignore", 
    message=".*More than 20 figures have been opened.*"
)

MIN_PLOT_BYTES = 10_000  # ~10 KB, tweak if you want


def save_plot_if_not_tiny(path, dpi=200, min_bytes=MIN_PLOT_BYTES):
    """
    Save current matplotlib figure to `path`.
    If the resulting file is smaller than `min_bytes`,
    delete it and report that it was skipped.
    Returns True if kept, False if deleted/failed.
    """
    import os
    import matplotlib.pyplot as plt

    plt.savefig(path, dpi=dpi)
    plt.close()

    try:
        size = os.path.getsize(path)
    except OSError:
        return False

    if size < min_bytes:
        try:
            os.remove(path)
            print(f"  Skipped near-empty plot (< {min_bytes} bytes): {os.path.basename(path)}")
        except OSError:
            pass
        return False

    return True

# NumPy compat
if not hasattr(np, "int"):
    np.int = int  # type: ignore[attr-defined]

# pandas.DataFrame.drop compat
_orig_drop = pd.DataFrame.drop
def _compat_drop(self, *args, **kwargs):
    if "axis" not in kwargs and len(args) >= 2:
        axis_candidate = args[1]
        if axis_candidate in (0, 1, "index", "columns"):
            args = (args[0],) + args[2:]
            kwargs["axis"] = axis_candidate
    return _orig_drop(self, *args, **kwargs)
pd.DataFrame.drop = _compat_drop  # type: ignore[assignment]


# -----------------------------------------------------------------------------
# Base paths and module setup
# -----------------------------------------------------------------------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Make project folders importable
sys.path.append(BASE_DIR)                           # so we can use `Functions.*`
sys.path.append(os.path.join(BASE_DIR, "Functions"))
sys.path.append(os.path.join(BASE_DIR, "DarkMatter"))  # so GenFT/UCP module import works
# Ensure all SPARC paths (Databases/, SPARC/) are resolved from the pipeline root
os.chdir(BASE_DIR)



# Output directory structure
OUTPUT_DIR = os.path.join(BASE_DIR, "Output")
TABLE_DIR = os.path.join(OUTPUT_DIR, "Tables")
PLOT_ROT_DIR = os.path.join(OUTPUT_DIR, "Plots", "MultiDM_Rotation")
PLOT_CURVE_DIR = os.path.join(OUTPUT_DIR, "Plots", "MultiDM_Curve")
PLOT_SCATTER_DIR = os.path.join(OUTPUT_DIR, "Plots", "MultiDM_Scatter")
PLOT_LENS_DIR = os.path.join(OUTPUT_DIR, "Plots", "MultiDM_Lensing")

os.makedirs(TABLE_DIR, exist_ok=True)
os.makedirs(PLOT_ROT_DIR, exist_ok=True)
os.makedirs(PLOT_LENS_DIR, exist_ok=True)

# ------------------ configuration ------------------
USE_THREADS = True      # set False to run sequentially
N_WORKERS   = 19       # number of worker threads when USE_THREADS is True -- tweak as needed, CPU dependent, may speed up processing

# Toggle individual DM profiles (and their imports)
USE_UCP              = True
USE_NFW              = True
USE_BURKERT          = True
USE_PSEUDO_ISO       = True
USE_EINASTO          = True
USE_DC14             = False
USE_STABLE_ATTRACTOR = True

# ---------------------------------------------------
# Toggle *tests* / metrics (and corresponding CSV columns)
COMPUTE_RAR      = True   # g_obs vs g_model residuals
COMPUTE_CURVE    = True   # slope / curvature tests
COMPUTE_SCATTER  = True   # ΔV scatter metrics
COMPUTE_LENSING  = True   # R_E_* columns (Einstein radius, lensing)

# Toggle plots
PLOT_ROTATION = True
PLOT_CURVE    = True
PLOT_SCATTER  = True
PLOT_LENSING  = True

import matplotlib
matplotlib.use("Agg")   # non-GUI backend; safe for threads
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker

from concurrent.futures import ThreadPoolExecutor, as_completed

import warnings
from scipy.integrate import quad, cumulative_trapezoid, IntegrationWarning
from scipy.interpolate import InterpolatedUnivariateSpline

# SPARC helper modules (from your Functions/ folder)
from Functions.GalaxyClass import SPARC
from Functions.Store import Store


# UCP (GenFT) lensing constants (from your Functions/genft_lensing.py)
from Functions import genft_lensing as gftlens
from Functions.genft_lensing import G_SI, C_SI, M_SUN_KG, KPC_M


# Silence the delim_whitespace FutureWarning from the SPARC helper
warnings.filterwarnings(
    "ignore",
    message=".*delim_whitespace.*",
    category=FutureWarning,
)

# Optionally silence invalid sqrt runtime warnings globally
np.seterr(invalid="ignore")

def tidy_legend(ax, *, outside=True, ncol=1, fontsize=8):
    """
    Build a clean legend for an Axes:
    - removes duplicate labels
    - optionally places legend outside the axes on the right
    """
    handles, labels = ax.get_legend_handles_labels()

    # de-duplicate while preserving order
    seen = set()
    clean_h, clean_l = [], []
    for h, lab in zip(handles, labels):
        if lab in seen:
            continue
        seen.add(lab)
        clean_h.append(h)
        clean_l.append(lab)

    if outside:
        ax.legend(
            clean_h,
            clean_l,
            loc="center left",
            bbox_to_anchor=(1.02, 0.5),   # outside, right side
            borderaxespad=0.0,
            frameon=False,
            fontsize=fontsize,
            ncol=ncol,
        )
    else:
        ax.legend(
            clean_h,
            clean_l,
            loc="upper left",
            frameon=False,
            fontsize=fontsize,
            ncol=ncol,
        )

# ----------------------------------------------------------------------
# Generic lensing helpers for ANY DM model with rho(p, r)
# ----------------------------------------------------------------------

# ----------------------------------------------------------------------
# Our own residual function (replaces SPARC Fitters.residual)
# ----------------------------------------------------------------------
def residual(params, model, x, data, err):
    """
    Residuals for lmfit.minimize.

    Parameters
    ----------
    params : lmfit.Parameters
        Current fit parameters.
    model : callable
        Function called as model(params, x_array) that returns model values.
    x : array-like or [array-like]
        Radial grid. In this pipeline we pass [R_kpc], so handle both.
    data : array-like
        Observed values (e.g. V_obs).
    err : array-like
        Errors on observed values (e.g. e_V).

    Returns
    -------
    res : ndarray
        (data - model) / err
    """
    # We pass x as [R_kpc], so unwrap if needed
    if isinstance(x, (list, tuple)):
        x_arr = x[0]
    else:
        x_arr = x

    model_vals = model(params, x_arr)
    return (data - model_vals) / err

# ----------------------------------------------------------------------
# Simple log10 tick formatter (avoids LaTeX, \mathdefault, etc.)
# ----------------------------------------------------------------------
def plain_log10_formatter(val, pos):
    """
    Format log-scale ticks as 1eN without using LaTeX/mathtext.
    Only label exact powers of 10.
    """
    if val <= 0:
        return ""
    exp = int(np.round(np.log10(val)))
    if np.isclose(val, 10.0**exp):
        return f"1e{exp}"
    return ""


def einstein_radius_from_alpha(R_kpc, alpha_rad, D_l_Mpc):
    """
    Solve alpha(R_E) = R_E / D_l for the Einstein radius R_E (in kpc).
    Uses sign-change detection plus brentq where possible,
    otherwise falls back to linear interpolation.
    """
    R = np.asarray(R_kpc, dtype=float)
    alpha = np.asarray(alpha_rad, dtype=float)

    if len(R) < 2:
        return float("nan")

    # Convert D_l to kpc
    D_l_kpc = D_l_Mpc * 1.0e3
    theta_R = R / D_l_kpc  # radians

    diff = alpha - theta_R

    # If no crossing (all positive or all negative), no strong lens
    if not (np.any(diff > 0.0) and np.any(diff < 0.0)):
        return float("nan")

    # --- First try a robust root finder ---
    def f(Ri):
        a = np.interp(Ri, R, alpha)
        t = Ri / D_l_kpc
        return a - t

    try:
        # Find a sign change interval
        for i in range(1, len(R)):
            if diff[i - 1] * diff[i] <= 0.0:
                R1, R2 = R[i - 1], R[i]
                return float(brentq(f, R1, R2, maxiter=200))
    except Exception:
        pass

    # --- Fallback: simple linear interpolation where sign changes ---
    for i in range(1, len(R)):
        if diff[i - 1] * diff[i] <= 0.0:
            R1, R2 = R[i - 1], R[i]
            d1, d2 = diff[i - 1], diff[i]
            if d1 == d2:
                return float(R1)
            t = -d1 / (d2 - d1)
            return float(R1 + t * (R2 - R1))

    return float("nan")


def sigma_profile_dm(dm_module, p, R, r_max_factor=50.0):
    """Compute projected surface density Σ(R) for a given DM profile rho(p, r).

    If the module declares ``RHO_UNITS == "Msun_pc3"`` the density is converted
    to ``Msun/kpc^3`` before integration to keep the lensing utilities
    consistent.
    """
    R = np.asarray(R, dtype=float)
    R = np.atleast_1d(R)
    Sigma = np.full_like(R, np.nan, dtype=float)

    # Fallback safety wrapper if module has no rho_safe
    if hasattr(dm_module, "rho_safe"):
        rho_func = dm_module.rho_safe
    elif hasattr(dm_module, "rho"):
        def rho_func(p_loc, r_kpc):
            try:
                val = float(dm_module.rho(p_loc, r_kpc))
            except Exception:
                return 0.0
            if not np.isfinite(val) or val < 0:
                return 0.0
            if val > 1e20:
                val = 1e20
            return val
    else:
        # No density at all – nothing to do
        return Sigma

    rho_units = getattr(dm_module, "RHO_UNITS", "Msun_kpc3")

    r_max_global = r_max_factor * np.nanmax(R)
    if not np.isfinite(r_max_global) or r_max_global <= 0:
        return Sigma

    # minimum radius to avoid singular behavior
    r_min = 5e-2  # 0.05 kpc

    for i, Ri in enumerate(R):
        if not np.isfinite(Ri) or Ri <= 0.0:
            continue

        # inner integration limit: at least r_min
        r_start = max(Ri, r_min)

        def integrand(r):
            rho_val = rho_func(p, r)
            if rho_units == "Msun_pc3":
                rho_val *= 1.0e9  # pc^3 -> kpc^3
            if not np.isfinite(rho_val) or rho_val <= 0.0:
                return 0.0
            denom = np.sqrt(max(r * r - Ri * Ri, 1e-30))
            return rho_val * r / denom

        try:
            # Catch and inspect SciPy IntegrationWarnings so we can
            # treat non-convergent integrals as "no reliable Sigma"
            with warnings.catch_warnings(record=True) as wlist:
                warnings.simplefilter("always", IntegrationWarning)
                val, _ = quad(
                    integrand,
                    r_start,
                    r_max_global,
                    epsabs=0.0,
                    epsrel=1.0e-5,
                    limit=200,
                )

            # If quad emitted an IntegrationWarning, skip this R
            if any(issubclass(w.category, IntegrationWarning) for w in wlist):
                # leave Sigma[i] as NaN on warning
                continue

            if np.isfinite(val):
                Sigma[i] = 2.0 * val
        except Exception:
            # leave Sigma[i] as NaN on error
            continue

    return Sigma


def m2d_profile_dm(R, Sigma):
    """
    Compute projected mass M_2D(<R) from Σ(R).
    
    Ignores non-finite entries; returns (R_sorted, M2D) or raises
    ValueError if fewer than 5 valid points.
    """
    R = np.asarray(R, dtype=float)
    Sigma = np.asarray(Sigma, dtype=float)

    mask = np.isfinite(R) & np.isfinite(Sigma) & (R > 0.0)
    if mask.sum() < 5:
        raise ValueError("Not enough valid points to build M2D profile")

    R_valid = R[mask]
    Sigma_valid = Sigma[mask]

    order = np.argsort(R_valid)
    R_sorted = R_valid[order]
    Sigma_sorted = Sigma_valid[order]

    integrand = Sigma_sorted * R_sorted
    M2D = 2.0 * np.pi * cumulative_trapezoid(integrand, R_sorted, initial=0.0)
    return R_sorted, M2D


def alpha_profile_dm(R, D_l_Mpc, D_s_Mpc, R_sorted, M2D):
    """
    Deflection angle α(R) for a given projected mass profile M2D(R).
    Returns an array of the same shape as R; if inputs are not usable,
    raises ValueError.
    """
    R = np.asarray(R, dtype=float)
    R_in = np.atleast_1d(R)

    R_sorted = np.asarray(R_sorted, dtype=float)
    M2D = np.asarray(M2D, dtype=float)

    mask = np.isfinite(R_sorted) & np.isfinite(M2D) & (R_sorted > 0.0)
    if mask.sum() < 5:
        raise ValueError("Not enough valid M2D points for alpha(R)")

    R_s = R_sorted[mask]
    M_s = M2D[mask]

    M2D_spline = InterpolatedUnivariateSpline(R_s, M_s, k=3)

    # Distances in meters
    D_l_m = D_l_Mpc * 1.0e6 * 3.085677581491367e16
    D_s_m = D_s_Mpc * 1.0e6 * 3.085677581491367e16
    D_ls_m = D_s_m - D_l_m
    geom = D_ls_m / D_s_m

    alpha = np.zeros_like(R_in, dtype=float)

    for i, Ri in enumerate(R_in):
        if not np.isfinite(Ri) or Ri <= 0.0:
            alpha[i] = 0.0
            continue

        M2D_R = float(M2D_spline(Ri))
        if not np.isfinite(M2D_R) or M2D_R <= 0.0:
            alpha[i] = 0.0
            continue
        b_m = Ri * KPC_M

        alpha_hat = 4.0 * G_SI * (M2D_R * M_SUN_KG) / (C_SI**2 * b_m)
        if not np.isfinite(alpha_hat) or alpha_hat < 0.0:
            alpha[i] = 0.0
            continue

        alpha[i] = geom * alpha_hat

    return alpha


# ----------------------------------------------------------------------
# Build SPARC object (shared)
# ----------------------------------------------------------------------

sparc_params = lf.Parameters()
sparc_params.add("M2L",  value=0.5, min=0.0)
sparc_params.add("M2Lb", value=0.5, min=0.0)
sparc_params.add("Rd",   value=1.0, min=0.0)
sparc_params.add("sig0", value=1.0, min=0.0)

criteria = Store("criteria")

sparc = SPARC(
    "MultiDM_all",
    sparc_params,
    criteria=criteria,
    makeprlm={"actions": ("make", "save"), "paths": None},
    aplycrit={"actions": ("apply", "save"), "paths": None},
    fiducial={"actions": ("make", "save"), "paths": None},
)

# ----------------------------------------------------------------------
# Register DM models based on toggles
# ----------------------------------------------------------------------

DM_CONFIG = {}

if USE_UCP:
    try:
        import GenFT as UCP
        DM_CONFIG["UCP"] = {
            "module": UCP,
            "dm_params": ["A", "s"],
        }
    except ImportError as e:
        print("Could not import UCP (GenFT) DM module:", e)

if USE_NFW:
    try:
        import NFW as NFW
        DM_CONFIG["NFW"] = {
            "module": NFW,
            "dm_params": ["rs", "ps"],  # G is fixed
        }
    except ImportError as e:
        print("Could not import NFW DM module:", e)

if USE_BURKERT:
    try:
        import Burkert as Burkert
        DM_CONFIG["Burkert"] = {
            "module": Burkert,
            "dm_params": ["rs", "ps"],
        }
    except ImportError as e:
        print("Could not import Burkert DM module:", e)

if USE_PSEUDO_ISO:
    try:
        import PseudoIsothermal as PseudoIsothermal
        DM_CONFIG["PseudoISO"] = {
            "module": PseudoIsothermal,
            "dm_params": ["rho0", "rc"],
        }
    except ImportError as e:
        print("Could not import PseudoIsothermal DM module:", e)

if USE_EINASTO:
    try:
        import Einasto as Einasto
        DM_CONFIG["Einasto"] = {
            "module": Einasto,
            "dm_params": ["rho2", "r2", "alpha"],
        }
    except ImportError as e:
        print("Could not import Einasto DM module:", e)

if USE_DC14:
    try:
        import DC14 as DC14
        DM_CONFIG["DC14"] = {
            "module": DC14,
            "dm_params": ["rho_s", "r_s", "alpha", "beta", "gamma"],
        }
    except ImportError as e:
        print("Could not import DC14 DM module:", e)

if USE_STABLE_ATTRACTOR:
    try:
        import StableAttractor as StableAttractor
        DM_CONFIG["StableAttractor"] = {
            "module": StableAttractor,
            "dm_params": ["rho0", "rc", "n"],
        }
    except ImportError as e:
        print("Could not import StableAttractor DM module:", e)

print("DM models:", list(DM_CONFIG.keys()))

if not DM_CONFIG:
    raise RuntimeError("No DM models enabled. Check toggles at top of script.")


# ----------------------------------------------------------------------
# Fit one DM model for one galaxy
# ----------------------------------------------------------------------

def fit_dm_model(model_name, cfg, gal_id,
                 R_kpc_full, V_obs_full, e_V_full, base_bar_params):
    dm_module = cfg["module"]

    # Initial baryons using base parameters, for masking
    def Vbar_base_from_p(p_fit):
        p_bar = base_bar_params.copy()
        p_bar["M2L"].value  = p_fit["M2L"].value
        p_bar["M2Lb"].value = p_fit["M2Lb"].value
        return sparc.Vbar(p_bar, gal_id)

    V_bar_base_full = Vbar_base_from_p(base_bar_params).astype(float)

    valid = (
        np.isfinite(R_kpc_full) &
        np.isfinite(V_obs_full) &
        np.isfinite(e_V_full) &
        np.isfinite(V_bar_base_full) &
        (e_V_full > 0.0)
    )

    if valid.sum() < 4:
        raise RuntimeError("Not enough valid data points")

    R_kpc = R_kpc_full[valid]
    V_obs = V_obs_full[valid]
    e_V   = e_V_full[valid]

    # Local helper: baryons for given params
    def Vbar_from_p(p_fit):
        p_bar = base_bar_params.copy()
        p_bar["M2L"].value  = p_fit["M2L"].value
        p_bar["M2Lb"].value = p_fit["M2Lb"].value
        V_bar_full = sparc.Vbar(p_bar, gal_id).astype(float)
        return V_bar_full[valid]

    # Build parameter set for this model
    p_fit = lf.Parameters()

    # Common baryonic params
    p_fit.add("M2L",  value=0.3, min=0.0, max=5.0)
    p_fit.add("M2Lb", value=0.3, min=0.0, max=5.0)

    if model_name == "UCP":
        p_fit.add("A", value=1.0, min=1e-6, max=100.0)
        p_fit.add("s", value=5.0, min=0.1,  max=50.0)

    elif model_name == "NFW":
        p_fit.add("G",  value=4.30091e-6, vary=False)
        p_fit.add("rs", value=5.0,  min=0.1, max=50.0)
        p_fit.add("ps", value=0.01, min=0.0, max=1.0)

    elif model_name == "Burkert":
        p_fit.add("G",  value=4.30091e-6, vary=False)
        p_fit.add("rs", value=5.0,  min=0.1, max=50.0)   # core radius [kpc]
        p_fit.add("ps", value=0.01, min=1e-5, max=10.0)  # central density [Msun/pc^3]

    elif model_name == "PseudoISO":
        p_fit.add("G",    value=4.30091e-6, vary=False)
        p_fit.add("rc",   value=5.0,  min=0.1, max=50.0)
        p_fit.add("rho0", value=0.01, min=1e-5, max=10.0)

    elif model_name == "Einasto":
        p_fit.add("G",     value=4.30091e-6, vary=False)
        p_fit.add("r2",    value=5.0,  min=0.1, max=50.0)
        p_fit.add("rho2",  value=0.01, min=1e-6, max=10.0)
        p_fit.add("alpha", value=0.2,  min=0.05, max=1.0)

    elif model_name == "DC14":
        p_fit.add("G",     value=4.30091e-6, vary=False)
        p_fit.add("r_s",   value=5.0,  min=0.1, max=50.0)
        p_fit.add("rho_s", value=1e6,  min=1e3, max=1e10)
        p_fit.add("alpha", value=1.0,  min=0.1, max=3.0)
        p_fit.add("beta",  value=3.0,  min=2.0, max=8.0)
        p_fit.add("gamma", value=1.0,  min=0.0, max=2.0)

    elif model_name == "StableAttractor":
        p_fit.add("G",    value=4.30091e-6, vary=False)
        p_fit.add("rho0", value=0.01, min=1e-6, max=100.0)
        p_fit.add("rc",   value=5.0,  min=0.1,  max=50.0)
        p_fit.add("n",    value=1.0,  min=0.5,  max=2.0)

    else:
        raise NotImplementedError(f"Parameter setup not implemented for {model_name}")

    # Model rotation curve using closure variables
    def Vtotal_model(p):
        # baryons:
        p_bar = base_bar_params.copy()
        p_bar["M2L"].value  = p["M2L"].value
        p_bar["M2Lb"].value = p["M2Lb"].value
        V_bar_full = sparc.Vbar(p_bar, gal_id).astype(float)
        V_bar = V_bar_full[valid]

        # DM:
        V_dm = dm_module.Vrot(p, R_kpc)

        return np.sqrt(V_bar**2 + V_dm**2)

    def model_wrapper(p, R):
        # R is ignored; lmfit just passes it through from Fitters.residual
        return Vtotal_model(p)

    result = lf.minimize(
        residual,
        p_fit,
        args=(model_wrapper, [R_kpc], V_obs, e_V),
        max_nfev=10000,
    )

    # Compute final pieces for plotting
    V_bar_best = Vbar_from_p(result.params)
    V_dm_best  = dm_module.Vrot(result.params, R_kpc)
    V_tot_best = np.sqrt(V_bar_best**2 + V_dm_best**2)

    return {
        "result": result,
        "R_kpc": R_kpc,
        "V_obs": V_obs,
        "e_V": e_V,
        "V_bar": V_bar_best,
        "V_dm": V_dm_best,
        "V_tot": V_tot_best,
        "valid_mask": valid,
    }


# --------------------------------------------------------
# Curve + Scatter evaluation helpers
# --------------------------------------------------------
def compute_curve_metrics(R, V_obs, e_V, V_model):
    """
    Very simple 'curve shape' test:
    - Fit a straight line to log(R) vs log(V_obs) and log(V_model)
    - Compare slopes and curvatures (2nd order poly fit)
    """
    R = np.asarray(R, dtype=float)
    V_obs = np.asarray(V_obs, dtype=float)
    V_model = np.asarray(V_model, dtype=float)

    mask = (R > 0.0) & (V_obs > 0.0) & (V_model > 0.0)
    if mask.sum() < 4:
        return {
            "curve_pass": False,
            "slope_err": np.nan,
            "curvature_err": np.nan,
        }

    x = np.log10(R[mask])
    y_obs = np.log10(V_obs[mask])
    y_mod = np.log10(V_model[mask])

    # Linear slope comparison
    p_obs_lin = np.polyfit(x, y_obs, 1)
    p_mod_lin = np.polyfit(x, y_mod, 1)
    slope_err = float(p_mod_lin[0] - p_obs_lin[0])

    # Quadratic 'curvature' comparison
    if mask.sum() >= 6:
        p_obs_quad = np.polyfit(x, y_obs, 2)
        p_mod_quad = np.polyfit(x, y_mod, 2)
        curvature_err = float(p_mod_quad[0] - p_obs_quad[0])
    else:
        curvature_err = np.nan

    curve_pass = (abs(slope_err) < 0.1) and (
        np.isnan(curvature_err) or abs(curvature_err) < 0.1
    )

    return {
        "curve_pass": curve_pass,
        "slope_err": slope_err,
        "curvature_err": curvature_err,
    }


def compute_scatter_metrics(V_obs, V_model):
    """
    Simple residual scatter metrics in velocity space.
    """
    V_obs = np.asarray(V_obs, dtype=float)
    V_model = np.asarray(V_model, dtype=float)

    mask = np.isfinite(V_obs) & np.isfinite(V_model)
    if mask.sum() < 3:
        return {
            "scatter_rms": np.nan,
            "scatter_med": np.nan,
            "scatter_max": np.nan,
        }

    resid = V_model[mask] - V_obs[mask]

    return {
        "scatter_rms": float(np.sqrt(np.mean(resid**2))),
        "scatter_med": float(np.median(np.abs(resid))),
        "scatter_max": float(np.max(np.abs(resid))),
    }


# ----------------------------------------------------------------------
# Per-galaxy processing: fits + plots + row dict
# ----------------------------------------------------------------------

def process_galaxy(gal_id):
    print(f"\n=== Fitting galaxy: {gal_id} ===")
    try:
        RC = sparc.fid.RCf.loc[gal_id]
        R_kpc_full = RC["R"].values.astype(float)
        V_obs_full = RC["Vobs"].values.astype(float)
        e_V_full   = RC["e_Vobs"].values.astype(float)

        base_bar_params = sparc.galx[gal_id].params.copy()

        model_outputs = {}
        row = {
            "gal_id": gal_id,
        }

        # Fit each enabled DM model
        for model_name, cfg in DM_CONFIG.items():
            try:
                out = fit_dm_model(
                    model_name,
                    cfg,
                    gal_id,
                    R_kpc_full,
                    V_obs_full,
                    e_V_full,
                    base_bar_params,
                )
                model_outputs[model_name] = out
                res = out["result"]

                # Basic fit stats
                row[f"chi2_{model_name}"]   = res.chisqr
                row[f"redchi_{model_name}"] = res.redchi
                row[f"aic_{model_name}"]    = res.aic
                row[f"bic_{model_name}"]    = res.bic
                row[f"M2L_{model_name}"]    = res.params["M2L"].value
                row[f"M2Lb_{model_name}"]   = res.params["M2Lb"].value

                # DM-specific parameters
                for pname in cfg["dm_params"]:
                    if pname in res.params:
                        row[f"{pname}_{model_name}"] = res.params[pname].value

                # ---------------- RAR metrics ----------------
                R_fit   = out["R_kpc"]   # kpc
                V_obs   = out["V_obs"]   # km/s
                V_bar   = out["V_bar"]   # km/s
                V_tot   = out["V_tot"]   # km/s

                if COMPUTE_RAR:
                    with np.errstate(divide="ignore", invalid="ignore"):
                        g_obs   = (V_obs**2) / R_fit
                        g_model = (V_tot**2) / R_fit

                    mask_rar = (
                        np.isfinite(g_obs) & np.isfinite(g_model) &
                        (g_obs > 0.0) & (g_model > 0.0) &
                        (R_fit > 0.0)
                    )

                    if mask_rar.sum() >= 3:
                        log_g_obs   = np.log10(g_obs[mask_rar])
                        log_g_model = np.log10(g_model[mask_rar])
                        rar_resid   = log_g_model - log_g_obs

                        row[f"rar_rms_{model_name}"] = float(
                            np.sqrt(np.mean(rar_resid**2))
                        )
                        row[f"rar_N_{model_name}"] = int(mask_rar.sum())
                    else:
                        row[f"rar_rms_{model_name}"] = np.nan
                        row[f"rar_N_{model_name}"]   = 0
                else:
                    row[f"rar_rms_{model_name}"] = np.nan
                    row[f"rar_N_{model_name}"]   = 0

                # ---------------- Curve test ----------------
                if COMPUTE_CURVE:
                    curve = compute_curve_metrics(
                        R_fit,
                        V_obs,
                        out["e_V"],   # masked errors from fit_dm_model
                        V_tot,
                    )
                    row[f"curve_pass_{model_name}"]          = curve["curve_pass"]
                    row[f"curve_slope_err_{model_name}"]     = curve["slope_err"]
                    row[f"curve_curvature_err_{model_name}"] = curve["curvature_err"]
                else:
                    row[f"curve_pass_{model_name}"]          = False
                    row[f"curve_slope_err_{model_name}"]     = np.nan
                    row[f"curve_curvature_err_{model_name}"] = np.nan

                # ---------------- Scatter test --------------
                if COMPUTE_SCATTER:
                    scatter = compute_scatter_metrics(V_obs, V_tot)
                    row[f"scatter_rms_{model_name}"] = scatter["scatter_rms"]
                    row[f"scatter_med_{model_name}"] = scatter["scatter_med"]
                    row[f"scatter_max_{model_name}"] = scatter["scatter_max"]
                else:
                    row[f"scatter_rms_{model_name}"] = np.nan
                    row[f"scatter_med_{model_name}"] = np.nan
                    row[f"scatter_max_{model_name}"] = np.nan

                # ---------------- Logging -------------------
                if COMPUTE_RAR:
                    print(
                        f"  {model_name} redchi = {res.redchi:.3g}, "
                        f"RAR_rms = {row[f'rar_rms_{model_name}']!r}"
                    )
                else:
                    print(
                        f"  {model_name} redchi = {res.redchi:.3g}"
                    )

            except Exception as e:
                print(f"  -> Error fitting {model_name} for {gal_id}: {e}")
                row[f"error_{model_name}"] = repr(e)

        # If no successful model, just return row
        if not model_outputs:
            return row

        # Use R_kpc from the first successful model as reference
        first_model = next(iter(model_outputs.values()))
        R_kpc = first_model["R_kpc"]
        V_obs = first_model["V_obs"]
        e_V   = first_model["e_V"]

        # ---------------- Rotation plot ----------------
        if PLOT_ROTATION:
            try:
                fig, ax = plt.subplots(figsize=(9, 5), constrained_layout=True)
                plotted_any = False

                # Observed data
                if np.isfinite(R_kpc).any() and np.isfinite(V_obs).any():
                    ax.errorbar(
                        R_kpc,
                        V_obs,
                        e_V,
                        fmt="o",
                        color="black",
                        label="Observed"
                    )
                    plotted_any = True

                color_cycle = plt.rcParams['axes.prop_cycle'].by_key()['color']

                for i, (model_name, out) in enumerate(model_outputs.items()):
                    V_tot = out["V_tot"]
                    V_dm  = out["V_dm"]

                    # Require at least some finite points
                    if (not np.isfinite(V_tot).any()) or (not np.isfinite(V_dm).any()):
                        continue

                    col = color_cycle[i % len(color_cycle)]

                    ax.plot(
                        R_kpc,
                        V_tot,
                        label=f"{model_name} total",
                        color=col,
                    )
                    ax.plot(
                        R_kpc,
                        V_dm,
                        linestyle="--",
                        color=col,
                        label=f"{model_name} DM",
                    )
                    plotted_any = True

                # If nothing sane got plotted, just close and skip this galaxy
                if not plotted_any:
                    plt.close(fig)
                else:
                    ax.set_xscale("log")
                    ax.xaxis.set_major_formatter(
                        mticker.FuncFormatter(plain_log10_formatter)
                    )

                    ax.set_xlabel("R [kpc]")
                    ax.set_ylabel("V [km/s]")
                    
                    # legend outside, 2 columns so it’s not a skyscraper
                    tidy_legend(ax, outside=True, ncol=1, fontsize=8)
                    
                    rot_path = os.path.join(PLOT_ROT_DIR, f"{gal_id}.png")
                    
                    if save_plot_if_not_tiny(rot_path, dpi=200):
                        print(f"  Saved rotation plot: {rot_path}")
            except Exception as e:
                print(f"  -> Error making rotation plot for {gal_id}: {e}")
                row["error_plot_rotation"] = repr(e)


        # ---------------- Curve diagnostic plot ----------------
        if PLOT_CURVE:
            try:
                # require at least 3 points and finite R, V for the reference model
                if (
                    len(R_kpc) >= 3
                    and np.all(np.isfinite(R_kpc))
                    and np.all(np.isfinite(V_obs))
                ):
                    os.makedirs(PLOT_CURVE_DIR, exist_ok=True)

                    fig, ax = plt.subplots(figsize=(9, 5), constrained_layout=True)
                    ax.plot(
                        R_kpc,
                        np.gradient(V_obs, R_kpc),
                        "o",
                        label="Observed dV/dR",
                    )

                    for model_name, out in model_outputs.items():
                        V_tot = out["V_tot"]
                        if (
                            len(V_tot) == len(R_kpc)
                            and np.all(np.isfinite(V_tot))
                        ):
                            ax.plot(
                                R_kpc,
                                np.gradient(V_tot, R_kpc),
                                label=f"{model_name} dV/dR",
                            )

                    ax.set_xscale("log")
                    ax.set_xlabel("R [kpc]")
                    ax.set_ylabel("Slope dV/dR")
                    tidy_legend(ax, outside=True, ncol=1, fontsize=8)

                    curve_path = os.path.join(PLOT_CURVE_DIR, f"{gal_id}.png")
                    save_plot_if_not_tiny(curve_path, dpi=200)
                else:
                    # not enough data to make a meaningful curve plot
                    row["error_plot_curve"] = "Insufficient data for curve plot"
            except Exception as e:
                row["error_plot_curve"] = repr(e)
                plt.close()

        # ---------------- Scatter plot ----------------
        if PLOT_SCATTER:
            try:
                os.makedirs(PLOT_SCATTER_DIR, exist_ok=True)
                fig, ax = plt.subplots(figsize=(9, 5), constrained_layout=True)
                for model_name, out in model_outputs.items():
                    diff = out["V_tot"] - out["V_obs"]
                    ax.plot(R_kpc, diff, label=f"{model_name} ΔV")
                ax.axhline(0, color="black", linewidth=0.8)
                ax.set_xscale("log")
                ax.set_xlabel("R [kpc]")
                ax.set_ylabel("ΔV = V_model - V_obs [km/s]")
                tidy_legend(ax, outside=True, ncol=1, fontsize=8)

                scat_path = os.path.join(PLOT_SCATTER_DIR, f"{gal_id}.png")
                save_plot_if_not_tiny(scat_path, dpi=200)
            except Exception as e:
                row["error_plot_scatter"] = repr(e)

        # ---------------- Lensing (metrics + plots) -----------------
        if COMPUTE_LENSING or PLOT_LENSING:
            try:
                D_l_Mpc = 20.0
                D_s_Mpc = 200.0
                R_lens = np.logspace(-2, 1.5, 150)

                color_cycle = plt.rcParams['axes.prop_cycle'].by_key()['color']
                if PLOT_LENSING:
                    fig, ax = plt.subplots(figsize=(9, 5), constrained_layout=True)

                any_lens_curve = False  # track if anything actually got plotted

                for i, (model_name, cfg) in enumerate(DM_CONFIG.items()):
                    if model_name not in model_outputs:
                        continue

                    dm_module = cfg["module"]
                    out = model_outputs[model_name]

                    try:
                        # Require a rho(p, r) function for lensing
                        if not (hasattr(dm_module, "rho") or hasattr(dm_module, "rho_safe")):
                            raise AttributeError(f"{model_name} has no rho(p, r) defined")

                        Sigma = sigma_profile_dm(dm_module, out["result"].params, R_lens)
                        if not np.isfinite(Sigma).any():
                            raise ValueError("Sigma contained no finite values")

                        R_sorted, M2D = m2d_profile_dm(R_lens, Sigma)
                        alpha = alpha_profile_dm(R_lens, D_l_Mpc, D_s_Mpc, R_sorted, M2D)

                        # Einstein radius for this model
                        try:
                            R_E = einstein_radius_from_alpha(R_lens, alpha, D_l_Mpc)
                        except Exception:
                            R_E = float("nan")

                        if not np.isfinite(R_E):
                            R_E = float("nan")

                        if COMPUTE_LENSING:
                            row[f"R_E_{model_name}"] = R_E

                        if PLOT_LENSING:
                            col = color_cycle[i % len(color_cycle)]
                            mask_plot = (
                                np.isfinite(R_lens)
                                & np.isfinite(alpha)
                                & (R_lens > 0.0)
                                & (alpha > 0.0)
                            )
                            if mask_plot.any():
                                ax.loglog(
                                    R_lens[mask_plot],
                                    alpha[mask_plot],
                                    label=f"{model_name} α(R)",
                                    color=col,
                                )

                                if np.isfinite(R_E):
                                    alpha_E = float(np.interp(R_E, R_lens[mask_plot], alpha[mask_plot]))
                                    if np.isfinite(alpha_E) and alpha_E > 0:
                                        ax.scatter([R_E], [alpha_E], color=col, marker="o", zorder=5)
                                any_lens_curve = True
                            else:
                                raise ValueError("No finite alpha values to plot")
                        else:
                            if np.isfinite(alpha).any():
                                any_lens_curve = True

                    except Exception as e:
                        print(f"  -> Error computing lensing for {model_name} in {gal_id}: {e}")
                        row[f"error_lens_{model_name}"] = repr(e)
                        continue


                if PLOT_LENSING and any_lens_curve:
                    os.makedirs(PLOT_LENS_DIR, exist_ok=True)
                    ax.xaxis.set_major_formatter(mticker.FuncFormatter(plain_log10_formatter))
                    ax.yaxis.set_major_formatter(mticker.FuncFormatter(plain_log10_formatter))

                    ax.set_xlabel("R [kpc]")
                    ax.set_ylabel("α(R) [radians]")

                    # use the same helper here
                    tidy_legend(ax, outside=True, ncol=1, fontsize=7)

                    lens_path = os.path.join(PLOT_LENS_DIR, f"{gal_id}.png")
                    if save_plot_if_not_tiny(lens_path, dpi=200):
                        print(f"  Saved lensing plot:  {lens_path}")

                elif PLOT_LENSING:
                    # No valid lens curves -> close empty figure
                    plt.close(fig)
                
            except Exception as e:
                print(f"  -> Error making lensing products for {gal_id}: {e}")
                row["error_plot_lensing"] = repr(e)

        return row

    except Exception as e:
        print(f"  -> Error processing {gal_id}: {e}")
        return {"gal_id": gal_id, "error": repr(e)}


# ----------------------------------------------------------------------
# Main: loop over galaxies (with optional threading)
# ----------------------------------------------------------------------

def main():
    all_rows = []
    gal_ids = list(sparc.useIDs)

    if USE_THREADS:
        print(f"\nRunning with multithreading: {N_WORKERS} workers\n")
        with ThreadPoolExecutor(max_workers=N_WORKERS) as ex:
            future_map = {ex.submit(process_galaxy, gid): gid for gid in gal_ids}
            for fut in as_completed(future_map):
                row = fut.result()
                all_rows.append(row)
    else:
        print("\nRunning sequentially (no multithreading)\n")
        for gid in gal_ids:
            row = process_galaxy(gid)
            all_rows.append(row)

    df = pd.DataFrame(all_rows)
    out_path = os.path.join(TABLE_DIR, "MultiDM_all.csv")
    df.to_csv(out_path, index=False)
    print(f"\nSaved results table to: {out_path}")

    # ------------------------------------------------------------
    # Global multi-profile summary (using BIC by default)
    # ------------------------------------------------------------
    profiles = list(DM_CONFIG.keys())

    print("\nGlobal profile summary (BIC, redchi, curve, scatter):")
    for model_name in profiles:
        bic_col = f"bic_{model_name}"
        redchi_col = f"redchi_{model_name}"

        if bic_col not in df.columns:
            continue

        valid = df[bic_col].notna()
        n_fit = int(valid.sum())
        n_total = len(df)
        n_fail = int(n_total - n_fit)

        if n_fit == 0:
            print(f"  {model_name}: no successful fits.")
            continue

        med_bic = float(df.loc[valid, bic_col].median())
        med_redchi = float(df.loc[valid, redchi_col].median())

        # Curve & scatter columns might not exist if you haven't added them
        curve_pass_col = f"curve_pass_{model_name}"
        scatter_rms_col = f"scatter_rms_{model_name}"

        if curve_pass_col in df.columns:
            n_curve = int(df.loc[valid, curve_pass_col].sum())
            frac_curve = n_curve / n_fit
        else:
            n_curve = None
            frac_curve = None

        if scatter_rms_col in df.columns:
            med_scatter_rms = float(df.loc[valid, scatter_rms_col].median())
        else:
            med_scatter_rms = None

        print(f"\n  [{model_name}]")
        print(f"    Fits:   {n_fit}")
        print(f"    Fails:  {n_fail}")
        print(f"    median BIC:     {med_bic:.3g}")
        print(f"    median redchi:  {med_redchi:.3g}")
        if n_curve is not None:
            print(f"    curve passes:   {n_curve} ({frac_curve:.3f} of fits)")
        if med_scatter_rms is not None:
            print(f"    median RMS scatter: {med_scatter_rms:.3g} km/s")

    # ------------------------------------------------------------
    # Pairwise UCP vs StableAttractor summary by BIC (if both present)
    # ------------------------------------------------------------
    if "bic_UCP" in df.columns and "bic_StableAttractor" in df.columns:
        mask_good = df["bic_UCP"].notna() & df["bic_StableAttractor"].notna()
        df_good = df[mask_good]

        n_total = len(df_good)
        if n_total > 0:
            n_ucp_better = int((df_good["bic_UCP"] < df_good["bic_StableAttractor"]).sum())
            n_sa_better  = int((df_good["bic_StableAttractor"] < df_good["bic_UCP"]).sum())

            print("\nSummary (UCP vs StableAttractor, BIC):")
            print(f"  Total galaxies fitted:          {n_total}")
            print(f"  UCP better (lower BIC):         {n_ucp_better}")
            print(f"  StableAttractor better (BIC):   {n_sa_better}")
            print(f"  UCP win fraction (BIC):         {n_ucp_better / n_total:.3f}")
        else:
            print("No successful galaxies to summarize for UCP vs StableAttractor (BIC).")
    else:
        print("UCP and/or StableAttractor not both present; skipping pairwise summary.")

    # ------------------------------------------------------------
    # Per-galaxy ranking by BIC (only models that fit)
    # ------------------------------------------------------------
    print("\nPer-galaxy ranking by BIC (only models that fit):")
    for _, row in df.iterrows():
        gal_id = row["gal_id"]
        scores = {}
        for model_name in profiles:
            col = f"bic_{model_name}"
            if col in df.columns and pd.notna(row.get(col, np.nan)):
                scores[model_name] = row[col]

        if len(scores) < 2:
            continue  # need at least 2 models to rank

        ranked = sorted(scores.items(), key=lambda kv: kv[1])  # lower BIC = better

        print(f"\n  Galaxy: {gal_id}")
        for rank, (mname, bic_val) in enumerate(ranked, start=1):
            redchi_val = row.get(f"redchi_{mname}", np.nan)
            curve_pass = row.get(f"curve_pass_{mname}", np.nan)
            print(
                f"    Rank {rank}: {mname}  "
                f"(BIC = {bic_val:.3g}, redchi = {redchi_val:.3g}, curve_pass = {curve_pass})"
            )


if __name__ == "__main__":
    main()