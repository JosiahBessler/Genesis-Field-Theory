#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
download_sparc.py

One-shot SPARC setup script for the GenesisFT Pipeline.

It will:
  1. Download Rotmod_LTG.zip (SPARC rotation-curve models)
     and extract to: SPARC/Rotmod_LTG/
  2. Download MaximumDiskPhytonCode.zip (official SPARC code bundle)
     and copy:
        Simulation_To_Publish/Functions/*  -> Functions/
        Simulation_To_Publish/Databases/* -> Databases/

No SPARC files are stored in your repo; they are fetched directly
from the official SPARC website when you run this script.
"""

import os
import sys
import urllib.request
import zipfile
import shutil

SPARC_BASE_URL = "https://astroweb.cwru.edu/SPARC"

ROT_ZIP_NAME = "Rotmod_LTG.zip"
ROT_ZIP_URL  = f"{SPARC_BASE_URL}/{ROT_ZIP_NAME}"

CODE_ZIP_NAME = "MaximumDiskPhytonCode.zip"
CODE_ZIP_URL  = f"{SPARC_BASE_URL}/{CODE_ZIP_NAME}"


def download(url: str, dest_folder: str) -> str:
    """Download a single file from `url` into `dest_folder`."""
    os.makedirs(dest_folder, exist_ok=True)
    local_path = os.path.join(dest_folder, os.path.basename(url))
    print(f"→ Downloading {url}")
    urllib.request.urlretrieve(url, local_path)
    print(f"   saved to {local_path}")
    return local_path


def extract_zip(path: str, dest_folder: str) -> None:
    """Extract a .zip archive into dest_folder."""
    os.makedirs(dest_folder, exist_ok=True)
    print(f"→ Extracting zip: {path} -> {dest_folder}")
    with zipfile.ZipFile(path, "r") as z:
        z.extractall(dest_folder)


def main():
    print("This script will set up the SPARC environment for the GenesisFT Pipeline.")
    print()
    print("Actions:")
    print("  1) Download Rotmod_LTG.zip (SPARC rotation-curve models)")
    print("  2) Download MaximumDiskPhytonCode.zip (SPARC Python code)")
    print("     and copy Functions/ and Databases/ into this pipeline.")
    print()
    print("By continuing, you agree to follow SPARC’s usage and citation rules")
    print("as described in Lelli, McGaugh & Schombert (2016).")
    print()

    ans = input("Continue? [y/N]: ").strip().lower()
    if ans != "y":
        print("Aborted.")
        sys.exit(0)

    base_dir = os.path.dirname(os.path.abspath(__file__))

    # ------------------------------------------------------------------
    # PART 1 — Rotmod_LTG.zip  →  SPARC/Rotmod_LTG/
    # ------------------------------------------------------------------
    sparc_data_dir = os.path.join(base_dir, "SPARC")
    os.makedirs(sparc_data_dir, exist_ok=True)

    print("\n=== Downloading SPARC Rotmod_LTG.zip ===")
    try:
        rot_zip_path = download(ROT_ZIP_URL, sparc_data_dir)
    except Exception as e:
        print(f"!! Failed to download {ROT_ZIP_NAME}: {e}")
        print("   You can also download it manually from:")
        print(f"   {ROT_ZIP_URL}")
        sys.exit(1)

    rot_out_dir = os.path.join(sparc_data_dir, "Rotmod_LTG")
    try:
        extract_zip(rot_zip_path, rot_out_dir)
    except Exception as e:
        print(f"!! Could not extract Rotmod_LTG.zip: {e}")
        sys.exit(1)

    # Clean up Rotmod zip after successful extract
    try:
        os.remove(rot_zip_path)
        print(f"   removed archive {rot_zip_path}")
    except OSError as e:
        print(f"   (warning) could not remove {rot_zip_path}: {e}")

    # ------------------------------------------------------------------
    # PART 2 — MaximumDiskPhytonCode.zip  →  Functions/ + Databases/
    # ------------------------------------------------------------------
    print("\n=== Downloading SPARC MaximumDiskPhytonCode.zip ===")
    try:
        code_zip_path = download(CODE_ZIP_URL, base_dir)
    except Exception as e:
        print(f"!! Failed to download {CODE_ZIP_NAME}: {e}")
        print("   You can also download it manually from:")
        print(f"   {CODE_ZIP_URL}")
        sys.exit(1)

    # Extract whole ZIP to a temp folder
    temp_extract_dir = os.path.join(base_dir, "_SPARC_raw")
    if os.path.exists(temp_extract_dir):
        shutil.rmtree(temp_extract_dir)
    extract_zip(code_zip_path, temp_extract_dir)

    # The structure inside the ZIP is:
    #   Simulation_To_Publish/
    #       Functions/
    #       Databases/
    sim_root = os.path.join(temp_extract_dir, "Simulation_To_Publish")
    src_functions = os.path.join(sim_root, "Functions")
    src_databases = os.path.join(sim_root, "Databases")

    dst_functions = os.path.join(base_dir, "Functions")
    dst_databases = os.path.join(base_dir, "Databases")

    os.makedirs(dst_functions, exist_ok=True)
    os.makedirs(dst_databases, exist_ok=True)

    # Copy Functions tree
    if os.path.isdir(src_functions):
        print("→ Copying Functions/ into pipeline")
        for root, dirs, files in os.walk(src_functions):
            rel_root = os.path.relpath(root, src_functions)
            target_root = os.path.join(dst_functions, rel_root)
            os.makedirs(target_root, exist_ok=True)
            for fname in files:
                src_path = os.path.join(root, fname)
                dst_path = os.path.join(target_root, fname)
                shutil.copy2(src_path, dst_path)
    else:
        print("!! Functions directory not found in MaximumDiskPhytonCode.zip")

    # Copy Databases tree
    if os.path.isdir(src_databases):
        print("→ Copying Databases/ into pipeline")
        for root, dirs, files in os.walk(src_databases):
            rel_root = os.path.relpath(root, src_databases)
            target_root = os.path.join(dst_databases, rel_root)
            os.makedirs(target_root, exist_ok=True)
            for fname in files:
                src_path = os.path.join(root, fname)
                dst_path = os.path.join(target_root, fname)
                shutil.copy2(src_path, dst_path)
    else:
        print("!! Databases directory not found in MaximumDiskPhytonCode.zip")

    # Optional: clean up the temp extraction
    shutil.rmtree(temp_extract_dir, ignore_errors=True)

    # Clean up MaximumDiskPhytonCode.zip as well
    try:
        os.remove(code_zip_path)
        print(f"   removed archive {code_zip_path}")
    except OSError as e:
        print(f"   (warning) could not remove {code_zip_path}: {e}")

    print("\n✔ SPARC setup complete.")
    print(f"   Rotmods directory:      {rot_out_dir}")
    print(f"   Functions directory:    {dst_functions}")
    print(f"   Databases directory:    {dst_databases}")
    print("\nYou should now be able to run:")
    print("   python fit_all_multiDM.py")


if __name__ == "__main__":
    main()
